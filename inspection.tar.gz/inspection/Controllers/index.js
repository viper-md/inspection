module.exports = {
    inspection_controller: require("./inspection-controller")
};